var require = meteorInstall({"imports":{"api":{"links.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/links.js                                              //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.export({
  LinksCollection: () => LinksCollection,
  taskCollection: () => taskCollection,
  ExpenseCollection: () => ExpenseCollection,
  ProfileCollection: () => ProfileCollection,
  IncomeCollection: () => IncomeCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const LinksCollection = new Mongo.Collection('links');
const taskCollection = new Mongo.Collection('tasks');
const ExpenseCollection = new Mongo.Collection('expense');
const ProfileCollection = new Mongo.Collection('profile');
const IncomeCollection = new Mongo.Collection('income');
///////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let LinksCollection;
module.link("/imports/api/links", {
  LinksCollection(v) {
    LinksCollection = v;
  }

}, 1);

function insertLink(_ref) {
  let {
    title,
    url
  } = _ref;
  LinksCollection.insert({
    title,
    url,
    createdAt: new Date()
  });
}

const SEED_USERNAME = 'meteorite';
const SEED_PASSWORD = 'password';
Meteor.startup(() => {
  if (!Accounts.findUserByUsername(SEED_USERNAME)) {
    Accounts.createUser({
      username: SEED_USERNAME,
      password: SEED_PASSWORD
    });
  } // If the Links collection is empty, add some data.


  if (LinksCollection.find().count() === 0) {
    insertLink({
      title: 'Do the Tutorial',
      url: 'https://www.meteor.com/tutorials/react/creating-an-app'
    });
    insertLink({
      title: 'Follow the Guide',
      url: 'http://guide.meteor.com'
    });
    insertLink({
      title: 'Read the Docs',
      url: 'https://docs.meteor.com'
    });
    insertLink({
      title: 'Discussions',
      url: 'https://forums.meteor.com'
    });
  }
});
///////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".mjs",
    ".jsx"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbGlua3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydCIsIkxpbmtzQ29sbGVjdGlvbiIsInRhc2tDb2xsZWN0aW9uIiwiRXhwZW5zZUNvbGxlY3Rpb24iLCJQcm9maWxlQ29sbGVjdGlvbiIsIkluY29tZUNvbGxlY3Rpb24iLCJNb25nbyIsImxpbmsiLCJ2IiwiQ29sbGVjdGlvbiIsIk1ldGVvciIsImluc2VydExpbmsiLCJ0aXRsZSIsInVybCIsImluc2VydCIsImNyZWF0ZWRBdCIsIkRhdGUiLCJTRUVEX1VTRVJOQU1FIiwiU0VFRF9QQVNTV09SRCIsInN0YXJ0dXAiLCJBY2NvdW50cyIsImZpbmRVc2VyQnlVc2VybmFtZSIsImNyZWF0ZVVzZXIiLCJ1c2VybmFtZSIsInBhc3N3b3JkIiwiZmluZCIsImNvdW50Il0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBQSxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDQyxpQkFBZSxFQUFDLE1BQUlBLGVBQXJCO0FBQXFDQyxnQkFBYyxFQUFDLE1BQUlBLGNBQXhEO0FBQXVFQyxtQkFBaUIsRUFBQyxNQUFJQSxpQkFBN0Y7QUFBK0dDLG1CQUFpQixFQUFDLE1BQUlBLGlCQUFySTtBQUF1SkMsa0JBQWdCLEVBQUMsTUFBSUE7QUFBNUssQ0FBZDtBQUE2TSxJQUFJQyxLQUFKO0FBQVVQLE1BQU0sQ0FBQ1EsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0QsT0FBSyxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsU0FBSyxHQUFDRSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRWhOLE1BQU1QLGVBQWUsR0FBRyxJQUFJSyxLQUFLLENBQUNHLFVBQVYsQ0FBcUIsT0FBckIsQ0FBeEI7QUFDQSxNQUFNUCxjQUFjLEdBQUcsSUFBSUksS0FBSyxDQUFDRyxVQUFWLENBQXFCLE9BQXJCLENBQXZCO0FBQ0EsTUFBTU4saUJBQWlCLEdBQUcsSUFBSUcsS0FBSyxDQUFDRyxVQUFWLENBQXFCLFNBQXJCLENBQTFCO0FBQ0EsTUFBTUwsaUJBQWlCLEdBQUcsSUFBSUUsS0FBSyxDQUFDRyxVQUFWLENBQXFCLFNBQXJCLENBQTFCO0FBQ0EsTUFBTUosZ0JBQWdCLEdBQUcsSUFBSUMsS0FBSyxDQUFDRyxVQUFWLENBQXFCLFFBQXJCLENBQXpCLEM7Ozs7Ozs7Ozs7O0FDTlAsSUFBSUMsTUFBSjtBQUFXWCxNQUFNLENBQUNRLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNHLFFBQU0sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLFVBQU0sR0FBQ0YsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJUCxlQUFKO0FBQW9CRixNQUFNLENBQUNRLElBQVAsQ0FBWSxvQkFBWixFQUFpQztBQUFDTixpQkFBZSxDQUFDTyxDQUFELEVBQUc7QUFBQ1AsbUJBQWUsR0FBQ08sQ0FBaEI7QUFBa0I7O0FBQXRDLENBQWpDLEVBQXlFLENBQXpFOztBQUdwRixTQUFTRyxVQUFULE9BQW9DO0FBQUEsTUFBaEI7QUFBRUMsU0FBRjtBQUFTQztBQUFULEdBQWdCO0FBQ2xDWixpQkFBZSxDQUFDYSxNQUFoQixDQUF1QjtBQUFDRixTQUFEO0FBQVFDLE9BQVI7QUFBYUUsYUFBUyxFQUFFLElBQUlDLElBQUo7QUFBeEIsR0FBdkI7QUFDRDs7QUFDRCxNQUFNQyxhQUFhLEdBQUcsV0FBdEI7QUFDQSxNQUFNQyxhQUFhLEdBQUcsVUFBdEI7QUFDQVIsTUFBTSxDQUFDUyxPQUFQLENBQWUsTUFBTTtBQUNuQixNQUFJLENBQUNDLFFBQVEsQ0FBQ0Msa0JBQVQsQ0FBNEJKLGFBQTVCLENBQUwsRUFBaUQ7QUFDL0NHLFlBQVEsQ0FBQ0UsVUFBVCxDQUFvQjtBQUNsQkMsY0FBUSxFQUFFTixhQURRO0FBRWxCTyxjQUFRLEVBQUVOO0FBRlEsS0FBcEI7QUFJRCxHQU5rQixDQVFuQjs7O0FBQ0EsTUFBSWpCLGVBQWUsQ0FBQ3dCLElBQWhCLEdBQXVCQyxLQUF2QixPQUFtQyxDQUF2QyxFQUEwQztBQUN4Q2YsY0FBVSxDQUFDO0FBQ1RDLFdBQUssRUFBRSxpQkFERTtBQUVUQyxTQUFHLEVBQUU7QUFGSSxLQUFELENBQVY7QUFLQUYsY0FBVSxDQUFDO0FBQ1RDLFdBQUssRUFBRSxrQkFERTtBQUVUQyxTQUFHLEVBQUU7QUFGSSxLQUFELENBQVY7QUFLQUYsY0FBVSxDQUFDO0FBQ1RDLFdBQUssRUFBRSxlQURFO0FBRVRDLFNBQUcsRUFBRTtBQUZJLEtBQUQsQ0FBVjtBQUtBRixjQUFVLENBQUM7QUFDVEMsV0FBSyxFQUFFLGFBREU7QUFFVEMsU0FBRyxFQUFFO0FBRkksS0FBRCxDQUFWO0FBSUQ7QUFDRixDQTlCRCxFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcblxyXG5leHBvcnQgY29uc3QgTGlua3NDb2xsZWN0aW9uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2xpbmtzJyk7XHJcbmV4cG9ydCBjb25zdCB0YXNrQ29sbGVjdGlvbiA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd0YXNrcycpO1xyXG5leHBvcnQgY29uc3QgRXhwZW5zZUNvbGxlY3Rpb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZXhwZW5zZScpO1xyXG5leHBvcnQgY29uc3QgUHJvZmlsZUNvbGxlY3Rpb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncHJvZmlsZScpO1xyXG5leHBvcnQgY29uc3QgSW5jb21lQ29sbGVjdGlvbiA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdpbmNvbWUnKTtcclxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBMaW5rc0NvbGxlY3Rpb24gfSBmcm9tICcvaW1wb3J0cy9hcGkvbGlua3MnO1xuXG5mdW5jdGlvbiBpbnNlcnRMaW5rKHsgdGl0bGUsIHVybCB9KSB7XG4gIExpbmtzQ29sbGVjdGlvbi5pbnNlcnQoe3RpdGxlLCB1cmwsIGNyZWF0ZWRBdDogbmV3IERhdGUoKX0pO1xufVxuY29uc3QgU0VFRF9VU0VSTkFNRSA9ICdtZXRlb3JpdGUnO1xuY29uc3QgU0VFRF9QQVNTV09SRCA9ICdwYXNzd29yZCc7XG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIGlmICghQWNjb3VudHMuZmluZFVzZXJCeVVzZXJuYW1lKFNFRURfVVNFUk5BTUUpKSB7XG4gICAgQWNjb3VudHMuY3JlYXRlVXNlcih7XG4gICAgICB1c2VybmFtZTogU0VFRF9VU0VSTkFNRSxcbiAgICAgIHBhc3N3b3JkOiBTRUVEX1BBU1NXT1JELFxuICAgIH0pO1xuICB9XG4gIFxuICAvLyBJZiB0aGUgTGlua3MgY29sbGVjdGlvbiBpcyBlbXB0eSwgYWRkIHNvbWUgZGF0YS5cbiAgaWYgKExpbmtzQ29sbGVjdGlvbi5maW5kKCkuY291bnQoKSA9PT0gMCkge1xuICAgIGluc2VydExpbmsoe1xuICAgICAgdGl0bGU6ICdEbyB0aGUgVHV0b3JpYWwnLFxuICAgICAgdXJsOiAnaHR0cHM6Ly93d3cubWV0ZW9yLmNvbS90dXRvcmlhbHMvcmVhY3QvY3JlYXRpbmctYW4tYXBwJ1xuICAgIH0pO1xuXG4gICAgaW5zZXJ0TGluayh7XG4gICAgICB0aXRsZTogJ0ZvbGxvdyB0aGUgR3VpZGUnLFxuICAgICAgdXJsOiAnaHR0cDovL2d1aWRlLm1ldGVvci5jb20nXG4gICAgfSk7XG5cbiAgICBpbnNlcnRMaW5rKHtcbiAgICAgIHRpdGxlOiAnUmVhZCB0aGUgRG9jcycsXG4gICAgICB1cmw6ICdodHRwczovL2RvY3MubWV0ZW9yLmNvbSdcbiAgICB9KTtcblxuICAgIGluc2VydExpbmsoe1xuICAgICAgdGl0bGU6ICdEaXNjdXNzaW9ucycsXG4gICAgICB1cmw6ICdodHRwczovL2ZvcnVtcy5tZXRlb3IuY29tJ1xuICAgIH0pO1xuICB9XG59KTtcbiJdfQ==
